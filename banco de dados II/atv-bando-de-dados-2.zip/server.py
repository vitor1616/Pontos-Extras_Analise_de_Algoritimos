# Vitor Jordão Caraneiro Briglia
#  flask --app lower-high/server run
# http://127.0.0.1:5000/

from flask import Flask
import random

app = Flask(__name__)

min = 0
max = 9

random_number = random.randint(min,max)

@app.route("/")
def home():
    return "<h1>Adivinhe o número entre 0 e 9!</h1><br>"\
    "<h2>Adicione o número após uma barra no endereço.<br> Ex.:http://127.0.0.1:5000/2</h2>"\
    "<img src='https://i.giphy.com/tHufwMDTUi20E.webp' alt='gifhome'>"

@app.route("/<int:num_user>")
def check_number(num_user):
    if num_user < random_number:
        return f"<h1> VOCÊ ERROU!! HAHAHA</h1>"\
        f"<h2>Não é {num_user}. Era um número mais alto...</h2>"\
        "<img src='https://i.giphy.com/14c9sviMHGJ6Bq.webp'>"
    elif num_user > random_number:
        return f"<h1> ERRADO!! KKKKKKKKKK</h1>"\
        f"<h2>Não é {num_user}. Era um número mais baixo...</h2>"\
        "<img src='https://i.giphy.com/LAPgyvIKblMyY.webp'>"
    else:
        return f"<h1>ACERTOU!! Era {num_user}. :)</h1>"\
        "<img src='https://i.giphy.com/qnGe1QqOeooOA.webp'>"

if __name__ == "__main__":
    app.run(debug=True)